| CTEname | Fibovar | constantefloat | constanteSymbols | constanteLatex |
| :--- | :--- | :--- | :--- | :--- |
| EJS_N2N1_P4N7_GC00010 | EJS_N2N1_P4N7 | 0.001025360661777899 | sqrt(65)*(121/8 - 15*sqrt(65)/8)/65 | $$\frac{\sqrt{65} \cdot \left(\frac{121}{8} - \frac{15 \sqrt{65}}{8}\right)}{65}$$ |
| EJS_P3N2_N5N8_GC00010 | EJS_P3N2_N5N8 | 0.001032815417674445 | sqrt(11)*(73/5 - 22*sqrt(11)/5)/22 | $$\frac{\sqrt{11} \cdot \left(\frac{73}{5} - \frac{22 \sqrt{11}}{5}\right)}{22}$$ |
| EJS_N9N8_P8N8_GC00010 | EJS_N9N8_P8N8 | 0.001041558182321950 | sqrt(6)*(49 - 20*sqrt(6))/24 | $$\frac{\sqrt{6} \cdot \left(49 - 20 \sqrt{6}\right)}{24}$$ |
| EJS_N4N2_P5N9_GC00010 | EJS_N4N2_P5N9 | 0.001042066602158498 | sqrt(101)*(191/5 - 19*sqrt(101)/5)/101 | $$\frac{\sqrt{101} \cdot \left(\frac{191}{5} - \frac{19 \sqrt{101}}{5}\right)}{101}$$ |
| EJS_N6P5_P8P9_GC00010 | EJS_N6P5_P8P9 | 0.001050097021778109 | -sqrt(113)*(627/16 - 59*sqrt(113)/16)/113 | $$- \frac{\sqrt{113} \cdot \left(\frac{627}{16} - \frac{59 \sqrt{113}}{16}\right)}{113}$$ |
| EJS_N3N1_P3N8_GC00010 | EJS_N3N1_P3N8 | 0.001052498648538747 | sqrt(19)*(109/3 - 25*sqrt(19)/3)/38 | $$\frac{\sqrt{19} \cdot \left(\frac{109}{3} - \frac{25 \sqrt{19}}{3}\right)}{38}$$ |
| EJS_P9P1_P1N10_GC00010 | EJS_P9P1_P1N10 | 0.001056647941304593 | sqrt(26)*(-464 + 91*sqrt(26))/52 | $$\frac{\sqrt{26} \left(-464 + 91 \sqrt{26}\right)}{52}$$ |
| EJS_N6P5_P4P4_GC00010 | EJS_N6P5_P4P4 | 0.001077746418943937 | -sqrt(2)*(41/2 - 29*sqrt(2)/2)/8 | $$- \frac{\sqrt{2} \cdot \left(\frac{41}{2} - \frac{29 \sqrt{2}}{2}\right)}{8}$$ |
| EJS_N5P3_P5P8_GC00011 | EJS_N5P3_P5P8 | 0.001107562350950089 | -sqrt(21)*(197/5 - 43*sqrt(21)/5)/42 | $$- \frac{\sqrt{21} \cdot \left(\frac{197}{5} - \frac{43 \sqrt{21}}{5}\right)}{42}$$ |
| EJS_P5N4_N5N7_GC00011 | EJS_P5N4_N5N7 | 0.001112147556766114 | sqrt(29)*(167/10 - 31*sqrt(29)/10)/29 | $$\frac{\sqrt{29} \cdot \left(\frac{167}{10} - \frac{31 \sqrt{29}}{10}\right)}{29}$$ |
| EJS_P6N2_N3N9_GC00011 | EJS_P6N2_N3N9 | 0.001114755508715788 | sqrt(69)*(72 - 26*sqrt(69)/3)/69 | $$\frac{\sqrt{69} \cdot \left(72 - \frac{26 \sqrt{69}}{3}\right)}{69}$$ |
| EJS_N2N1_P6N10_GC00011 | EJS_N2N1_P6N10 | 0.001151694761055281 | sqrt(31)*(39/2 - 7*sqrt(31)/2)/62 | $$\frac{\sqrt{31} \cdot \left(\frac{39}{2} - \frac{7 \sqrt{31}}{2}\right)}{62}$$ |
| EJS_P8N2_N2N8_GC00011 | EJS_P8N2_N2N8 | 0.001152030920614311 | sqrt(14)*(116 - 31*sqrt(14))/28 | $$\frac{\sqrt{14} \cdot \left(116 - 31 \sqrt{14}\right)}{28}$$ |
| EJS_N9P3_P3P9_GC00011 | EJS_N9P3_P3P9 | 0.001152121139258877 | -sqrt(93)*(135 - 14*sqrt(93))/93 | $$- \frac{\sqrt{93} \cdot \left(135 - 14 \sqrt{93}\right)}{93}$$ |
| EJS_P3P1_P3N10_GC00011 | EJS_P3P1_P3N10 | 0.001152202207227894 | sqrt(7)*(-164/3 + 62*sqrt(7)/3)/28 | $$\frac{\sqrt{7} \left(- \frac{164}{3} + \frac{62 \sqrt{7}}{3}\right)}{28}$$ |
| EJS_N1P1_P8P8_GC00011 | EJS_N1P1_P8P8 | 0.001158600612188352 | -sqrt(6)*(11/2 - 9*sqrt(6)/4)/24 | $$- \frac{\sqrt{6} \cdot \left(\frac{11}{2} - \frac{9 \sqrt{6}}{4}\right)}{24}$$ |
| EJS_N10N1_P1N9_GC00011 | EJS_N10N1_P1N9 | 0.001163527463132077 | sqrt(85)*(839/2 - 91*sqrt(85)/2)/85 | $$\frac{\sqrt{85} \cdot \left(\frac{839}{2} - \frac{91 \sqrt{85}}{2}\right)}{85}$$ |
| EJS_N10N6_P4N6_GC00011 | EJS_N10N6_P4N6 | 0.001165418850283190 | sqrt(13)*(119/2 - 33*sqrt(13)/2)/26 | $$\frac{\sqrt{13} \cdot \left(\frac{119}{2} - \frac{33 \sqrt{13}}{2}\right)}{26}$$ |
| EJS_N1N3P2_N1P3P3_GC00011 | EJS_N1N3P2_N1P3P3 | 0.001173592526997419 | (1 - 14*(2 - sqrt(3))**2)/(-15 + 3*(2 - sqrt(3))**2 + 6*sqrt(3)) | $$\frac{1 - 14 \left(2 - \sqrt{3}\right)^{2}}{-15 + 3 \left(2 - \sqrt{3}\right)^{2} + 6 \sqrt{3}}$$ |
| EJS_N4P1_N2N9_GC00011 | EJS_N4P1_N2N9 | 0.001174247089240345 | sqrt(73)*(-299/4 + 35*sqrt(73)/4)/73 | $$\frac{\sqrt{73} \left(- \frac{299}{4} + \frac{35 \sqrt{73}}{4}\right)}{73}$$ |
| EJS_N10P7_P6P8_GC00011 | EJS_N10P7_P6P8 | 0.001175643909245233 | -sqrt(22)*(68 - 29*sqrt(22)/2)/44 | $$- \frac{\sqrt{22} \cdot \left(68 - \frac{29 \sqrt{22}}{2}\right)}{44}$$ |
| EJS_N4P3_P7P9_GC00011 | EJS_N4P3_P7P9 | 0.001176442249938451 | -sqrt(109)*(407/14 - 39*sqrt(109)/14)/109 | $$- \frac{\sqrt{109} \cdot \left(\frac{407}{14} - \frac{39 \sqrt{109}}{14}\right)}{109}$$ |
| EJS_N5N3_P6N9_GC00011 | EJS_N5N3_P6N9 | 0.001190299088986035 | sqrt(105)*(41 - 4*sqrt(105))/105 | $$\frac{\sqrt{105} \cdot \left(41 - 4 \sqrt{105}\right)}{105}$$ |
| EJS_P6P3_P5N10_GC00011 | EJS_P6P3_P5N10 | 0.001190588690589695 | sqrt(30)*(-69 + 63*sqrt(30)/5)/60 | $$\frac{\sqrt{30} \left(-69 + \frac{63 \sqrt{30}}{5}\right)}{60}$$ |
| EJS_N3P1_P2P6_GC00011 | EJS_N3P1_P2P6 | 0.001196322900222943 | -sqrt(11)*(63/2 - 19*sqrt(11)/2)/22 | $$- \frac{\sqrt{11} \cdot \left(\frac{63}{2} - \frac{19 \sqrt{11}}{2}\right)}{22}$$ |
| EJS_N3N2N1_N1P3N3_GC00012 | EJS_N3N2N1_N1P3N3 | 0.001207539160180275 | (-11*2**(1/3) - 2*(1 - 2**(1/3))**2 + 14)/(-3 + 3*(1 - 2**(1/3))**2 + 6*2**(1/3)) | $$\frac{- 11 \cdot \sqrt[3]{2} - 2 \left(1 - \sqrt[3]{2}\right)^{2} + 14}{-3 + 3 \left(1 - \sqrt[3]{2}\right)^{2} + 6 \cdot \sqrt[3]{2}}$$ |
| EJS_P7N5_N6N9_GC00012 | EJS_P7N5_N6N9 | 0.001209769954076560 | sqrt(57)*(73/2 - 29*sqrt(57)/6)/57 | $$\frac{\sqrt{57} \cdot \left(\frac{73}{2} - \frac{29 \sqrt{57}}{6}\right)}{57}$$ |
| EJS_N5N4_P9N10_GC00012 | EJS_N5N4_P9N10 | 0.001225239993904654 | sqrt(34)*(35 - 6*sqrt(34))/68 | $$\frac{\sqrt{34} \cdot \left(35 - 6 \sqrt{34}\right)}{68}$$ |
| EJS_N6P4_P5P7_GC00012 | EJS_N6P4_P5P7 | 0.001260412123616530 | -sqrt(69)*(191/5 - 23*sqrt(69)/5)/69 | $$- \frac{\sqrt{69} \cdot \left(\frac{191}{5} - \frac{23 \sqrt{69}}{5}\right)}{69}$$ |
| EJS_N8P1_N1N9_GC00012 | EJS_N8P1_N1N9 | 0.001280432822778937 | sqrt(77)*(-623/2 + 71*sqrt(77)/2)/77 | $$\frac{\sqrt{77} \left(- \frac{623}{2} + \frac{71 \sqrt{77}}{2}\right)}{77}$$ |
| EJS_N1P0_P1N9_GC00013 | EJS_N1P0_P1N9 | 0.001306999737115569 | sqrt(85)*(83/2 - 9*sqrt(85)/2)/85 | $$\frac{\sqrt{85} \cdot \left(\frac{83}{2} - \frac{9 \sqrt{85}}{2}\right)}{85}$$ |
| EJS_N3P2_P6P9_GC00013 | EJS_N3P2_P6P9 | 0.001313986119047047 | -sqrt(105)*(99/4 - 29*sqrt(105)/12)/105 | $$- \frac{\sqrt{105} \cdot \left(\frac{99}{4} - \frac{29 \sqrt{105}}{12}\right)}{105}$$ |
| EJS_P4N2_N5N10_GC00013 | EJS_P4N2_N5N10 | 0.001315561749642483 | sqrt(5)*(34 - 76*sqrt(5)/5)/20 | $$\frac{\sqrt{5} \cdot \left(34 - \frac{76 \sqrt{5}}{5}\right)}{20}$$ |
| EJS_N5N2_P4N9_GC00013 | EJS_N5N2_P4N9 | 0.001315930710820214 | sqrt(97)*(463/8 - 47*sqrt(97)/8)/97 | $$\frac{\sqrt{97} \cdot \left(\frac{463}{8} - \frac{47 \sqrt{97}}{8}\right)}{97}$$ |
| EJS_N8P6_P5P6_GC00013 | EJS_N8P6_P5P6 | 0.001322913369027429 | -sqrt(14)*(202/5 - 54*sqrt(14)/5)/28 | $$- \frac{\sqrt{14} \cdot \left(\frac{202}{5} - \frac{54 \sqrt{14}}{5}\right)}{28}$$ |
| EJS_N4N3_P6N7_GC00013 | EJS_N4N3_P6N7 | 0.001325333914549953 | sqrt(73)*(265/12 - 31*sqrt(73)/12)/73 | $$\frac{\sqrt{73} \cdot \left(\frac{265}{12} - \frac{31 \sqrt{73}}{12}\right)}{73}$$ |
| EJS_N5P1_P1P5_GC00013 | EJS_N5P1_P1P5 | 0.001326327606369579 | -sqrt(29)*(70 - 13*sqrt(29))/29 | $$- \frac{\sqrt{29} \cdot \left(70 - 13 \sqrt{29}\right)}{29}$$ |
| EJS_P1P1_P9N10_GC00013 | EJS_P1P1_P9N10 | 0.001338363937746355 | sqrt(34)*(-64/9 + 11*sqrt(34)/9)/68 | $$\frac{\sqrt{34} \left(- \frac{64}{9} + \frac{11 \sqrt{34}}{9}\right)}{68}$$ |
| EJS_P1P2P2_N3P3N1_GC00013 | EJS_P1P2P2_N3P3N1 | 0.001369089545941967 | (-2 - (1/3 - 10**(1/3)/3)**2 + 10**(1/3))/(-1 + 9*(1/3 - 10**(1/3)/3)**2 + 2*10**(1/3)) | $$\frac{-2 - \left(\frac{1}{3} - \frac{\sqrt[3]{10}}{3}\right)^{2} + \sqrt[3]{10}}{-1 + 9 \left(\frac{1}{3} - \frac{\sqrt[3]{10}}{3}\right)^{2} + 2 \cdot \sqrt[3]{10}}$$ |
| EJS_P5P3_P6N10_GC00013 | EJS_P5P3_P6N10 | 0.001369658508450357 | sqrt(31)*(-295/6 + 53*sqrt(31)/6)/62 | $$\frac{\sqrt{31} \left(- \frac{295}{6} + \frac{53 \sqrt{31}}{6}\right)}{62}$$ |
| EJS_N7P2_P2P7_GC00013 | EJS_N7P2_P2P7 | 0.001376063248953362 | -sqrt(57)*(385/4 - 51*sqrt(57)/4)/57 | $$- \frac{\sqrt{57} \cdot \left(\frac{385}{4} - \frac{51 \sqrt{57}}{4}\right)}{57}$$ |
| EJS_P2N1_N4N8_GC00013 | EJS_P2N1_N4N8 | 0.001388374866283734 | sqrt(3)*(13 - 15*sqrt(3)/2)/12 | $$\frac{\sqrt{3} \cdot \left(13 - \frac{15 \sqrt{3}}{2}\right)}{12}$$ |
| EJS_N3N1_P4N10_GC00013 | EJS_N3N1_P4N10 | 0.001390184445957643 | sqrt(29)*(167/4 - 31*sqrt(29)/4)/58 | $$\frac{\sqrt{29} \cdot \left(\frac{167}{4} - \frac{31 \sqrt{29}}{4}\right)}{58}$$ |
| EJS_N3P4_P7P4_GC00014 | EJS_N3P4_P7P4 | 0.001421338384180571 | -sqrt(11)*(53/7 - 16*sqrt(11)/7)/22 | $$- \frac{\sqrt{11} \cdot \left(\frac{53}{7} - \frac{16 \sqrt{11}}{7}\right)}{22}$$ |
| EJS_N9P8_N8N10_GC00014 | EJS_N9P8_N8N10 | 0.001434921107465934 | sqrt(17)*(-169/4 + 41*sqrt(17)/4)/34 | $$\frac{\sqrt{17} \left(- \frac{169}{4} + \frac{41 \sqrt{17}}{4}\right)}{34}$$ |
| EJS_N8N7_P7N7_GC00014 | EJS_N8N7_P7N7 | 0.001442770155698979 | sqrt(77)*(79/2 - 9*sqrt(77)/2)/77 | $$\frac{\sqrt{77} \cdot \left(\frac{79}{2} - \frac{9 \sqrt{77}}{2}\right)}{77}$$ |
| EJS_N10N8_P8N9_GC00014 | EJS_N10N8_P8N9 | 0.001444655348177368 | sqrt(113)*(521/8 - 49*sqrt(113)/8)/113 | $$\frac{\sqrt{113} \cdot \left(\frac{521}{8} - \frac{49 \sqrt{113}}{8}\right)}{113}$$ |
| EJS_N8P1_P1P9_GC00014 | EJS_N8P1_P1P9 | 0.001450472011099060 | -sqrt(85)*(673/2 - 73*sqrt(85)/2)/85 | $$- \frac{\sqrt{85} \cdot \left(\frac{673}{2} - \frac{73 \sqrt{85}}{2}\right)}{85}$$ |
| EJS_P7P6_P9N10_GC00014 | EJS_P7P6_P9N10 | 0.001451487881588057 | sqrt(34)*(-443/9 + 76*sqrt(34)/9)/68 | $$\frac{\sqrt{34} \left(- \frac{443}{9} + \frac{76 \sqrt{34}}{9}\right)}{68}$$ |
| EJS_N1N1_P9N7_GC00014 | EJS_N1N1_P9N7 | 0.001468163293904353 | sqrt(85)*(37/9 - 4*sqrt(85)/9)/85 | $$\frac{\sqrt{85} \cdot \left(\frac{37}{9} - \frac{4 \sqrt{85}}{9}\right)}{85}$$ |
| EJS_N4P2_P4P8_GC00014 | EJS_N4P2_P4P8 | 0.001470842750399576 | -sqrt(5)*(38 - 17*sqrt(5))/20 | $$- \frac{\sqrt{5} \cdot \left(38 - 17 \sqrt{5}\right)}{20}$$ |
| EJS_N4P1_P2P9_GC00015 | EJS_N4P1_P2P9 | 0.001518496944509184 | -sqrt(89)*(349/4 - 37*sqrt(89)/4)/89 | $$- \frac{\sqrt{89} \cdot \left(\frac{349}{4} - \frac{37 \sqrt{89}}{4}\right)}{89}$$ |
| EJS_N1P1P1_N1P3N3_GC00015 | EJS_N1P1P1_N1P3N3 | 0.001521404006483506 | (-2*2**(1/3) - 7*(1 - 2**(1/3))**2 + 3)/(-3 + 3*(1 - 2**(1/3))**2 + 6*2**(1/3)) | $$\frac{- 2 \cdot \sqrt[3]{2} - 7 \left(1 - \sqrt[3]{2}\right)^{2} + 3}{-3 + 3 \left(1 - \sqrt[3]{2}\right)^{2} + 6 \cdot \sqrt[3]{2}}$$ |
| EJS_N4N1_P3N10_GC00015 | EJS_N4N1_P3N10 | 0.001524220250192358 | sqrt(7)*(217/3 - 82*sqrt(7)/3)/28 | $$\frac{\sqrt{7} \cdot \left(\frac{217}{3} - \frac{82 \sqrt{7}}{3}\right)}{28}$$ |
| EJS_N6N3_P5N9_GC00015 | EJS_N6N3_P5N9 | 0.001563099903237747 | sqrt(101)*(573/10 - 57*sqrt(101)/10)/101 | $$\frac{\sqrt{101} \cdot \left(\frac{573}{10} - \frac{57 \sqrt{101}}{10}\right)}{101}$$ |
| EJS_N6P2_N3N10_GC00015 | EJS_N6P2_N3N10 | 0.001567525212326978 | sqrt(22)*(-272/3 + 58*sqrt(22)/3)/44 | $$\frac{\sqrt{22} \left(- \frac{272}{3} + \frac{58 \sqrt{22}}{3}\right)}{44}$$ |
| EJS_P8N5_N6N10_GC00015 | EJS_P8N5_N6N10 | 0.001578747972808120 | sqrt(19)*(109/2 - 25*sqrt(19)/2)/38 | $$\frac{\sqrt{19} \cdot \left(\frac{109}{2} - \frac{25 \sqrt{19}}{2}\right)}{38}$$ |
| EJS_N3N2_P7N9_GC00015 | EJS_N3N2_P7N9 | 0.001581174442920514 | sqrt(109)*(303/14 - 29*sqrt(109)/14)/109 | $$\frac{\sqrt{109} \cdot \left(\frac{303}{14} - \frac{29 \sqrt{109}}{14}\right)}{109}$$ |
| EJS_P8P4_P5N10_GC00015 | EJS_P8P4_P5N10 | 0.001587451587452926 | sqrt(30)*(-92 + 84*sqrt(30)/5)/60 | $$\frac{\sqrt{30} \left(-92 + \frac{84 \sqrt{30}}{5}\right)}{60}$$ |
| EJS_N7P9_P8P5_GC00015 | EJS_N7P9_P8P5 | 0.001595359090034101 | -sqrt(57)*(83/4 - 11*sqrt(57)/4)/57 | $$- \frac{\sqrt{57} \cdot \left(\frac{83}{4} - \frac{11 \sqrt{57}}{4}\right)}{57}$$ |
| EJS_N2P1_P3P6_GC00016 | EJS_N2P1_P3P6 | 0.001603157205570049 | -sqrt(3)*(15 - 26*sqrt(3)/3)/12 | $$- \frac{\sqrt{3} \cdot \left(15 - \frac{26 \sqrt{3}}{3}\right)}{12}$$ |
| EJS_N10N1_N1P9_GC00016 | EJS_N10N1_N1P9 | 0.001605107488619020 | -sqrt(77)*(-781/2 + 89*sqrt(77)/2)/77 | $$- \frac{\sqrt{77} \left(- \frac{781}{2} + \frac{89 \sqrt{77}}{2}\right)}{77}$$ |
| EJS_N9N1_P1N8_GC00016 | EJS_N9N1_P1N8 | 0.001611567968112514 | sqrt(17)*(301 - 73*sqrt(17))/34 | $$\frac{\sqrt{17} \cdot \left(301 - 73 \sqrt{17}\right)}{34}$$ |
| EJS_N7P8_N10N10_GC00016 | EJS_N7P8_N10N10 | 0.001613323034066491 | sqrt(15)*(-24 + 31*sqrt(15)/5)/30 | $$\frac{\sqrt{15} \left(-24 + \frac{31 \sqrt{15}}{5}\right)}{30}$$ |
| EJS_N1P1_P7P7_GC00016 | EJS_N1P1_P7P7 | 0.001625689130381684 | -sqrt(77)*(5 - 4*sqrt(77)/7)/77 | $$- \frac{\sqrt{77} \cdot \left(5 - \frac{4 \sqrt{77}}{7}\right)}{77}$$ |
| EJS_N2P1_P4P9_GC00016 | EJS_N2P1_P4P9 | 0.001628339000165485 | -sqrt(97)*(187/8 - 19*sqrt(97)/8)/97 | $$- \frac{\sqrt{97} \cdot \left(\frac{187}{8} - \frac{19 \sqrt{97}}{8}\right)}{97}$$ |
| EJS_N8P9_P9P7_GC00016 | EJS_N8P9_P9P7 | 0.001629326850693138 | -sqrt(85)*(599/18 - 65*sqrt(85)/18)/85 | $$- \frac{\sqrt{85} \cdot \left(\frac{599}{18} - \frac{65 \sqrt{85}}{18}\right)}{85}$$ |
| EJS_N9N8_P9N9_GC00016 | EJS_N9N8_P9N9 | 0.001632305230515226 | sqrt(13)*(107/2 - 89*sqrt(13)/6)/39 | $$\frac{\sqrt{13} \cdot \left(\frac{107}{2} - \frac{89 \sqrt{13}}{6}\right)}{39}$$ |
| EJS_N1P1_N8N10_GC00016 | EJS_N1P1_N8N10 | 0.001636367103479998 | sqrt(17)*(-37/8 + 9*sqrt(17)/8)/34 | $$\frac{\sqrt{17} \left(- \frac{37}{8} + \frac{9 \sqrt{17}}{8}\right)}{34}$$ |
| EJS_P5N6_N7N7_GC00016 | EJS_P5N6_N7N7 | 0.001641385813356193 | sqrt(21)*(19/2 - 29*sqrt(21)/14)/21 | $$\frac{\sqrt{21} \cdot \left(\frac{19}{2} - \frac{29 \sqrt{21}}{14}\right)}{21}$$ |
| EJS_N5P6_P5P3_GC00016 | EJS_N5P6_P5P3 | 0.001642678599313946 | -sqrt(29)*(113/10 - 21*sqrt(29)/10)/29 | $$- \frac{\sqrt{29} \cdot \left(\frac{113}{10} - \frac{21 \sqrt{29}}{10}\right)}{29}$$ |
| EJS_N3P2N1_P2P2N3_GC00016 | EJS_N3P2N1_P2P2N3 | 0.001667185508070086 | (-4 - 11*(-1 + sqrt(2)/2)**2 + 7*sqrt(2)/2)/(-2*sqrt(2) - 6*(-1 + sqrt(2)/2)**2 + 7) | $$\frac{-4 - 11 \left(-1 + \frac{\sqrt{2}}{2}\right)^{2} + \frac{7 \sqrt{2}}{2}}{- 2 \sqrt{2} - 6 \left(-1 + \frac{\sqrt{2}}{2}\right)^{2} + 7}$$ |
| EJS_N6N1_P2N10_GC00016 | EJS_N6N1_P2N10 | 0.001669611092613945 | sqrt(3)*(317/2 - 183*sqrt(3)/2)/18 | $$\frac{\sqrt{3} \cdot \left(\frac{317}{2} - \frac{183 \sqrt{3}}{2}\right)}{18}$$ |
| EJS_P9N3_N3N9_GC00016 | EJS_P9N3_N3N9 | 0.001672133263073682 | sqrt(69)*(108 - 13*sqrt(69))/69 | $$\frac{\sqrt{69} \cdot \left(108 - 13 \sqrt{69}\right)}{69}$$ |
| EJS_N9P5_N3N6_GC00017 | EJS_N9P5_N3N6 | 0.001700857389406339 | sqrt(6)*(-40 + 49*sqrt(6)/3)/12 | $$\frac{\sqrt{6} \left(-40 + \frac{49 \sqrt{6}}{3}\right)}{12}$$ |
| EJS_N2P2_P9P9_GC00017 | EJS_N2P2_P9P9 | 0.001710718660652867 | -sqrt(13)*(12 - 10*sqrt(13)/3)/39 | $$- \frac{\sqrt{13} \cdot \left(12 - \frac{10 \sqrt{13}}{3}\right)}{39}$$ |
| EJS_N7N5_P8N10_GC00017 | EJS_N7N5_P8N10 | 0.001716857306610515 | sqrt(33)*(431/8 - 75*sqrt(33)/8)/66 | $$\frac{\sqrt{33} \cdot \left(\frac{431}{8} - \frac{75 \sqrt{33}}{8}\right)}{66}$$ |
| EJS_P1N3P2_N4P2P3_GC00017 | EJS_P1N3P2_N4P2P3 | 0.001722092687431651 | (-5/2 - 9*(-1/4 + sqrt(5)/4)**2 + 3*sqrt(5)/2)/(-sqrt(5) - 2 + 12*(-1/4 + sqrt(5)/4)**2) | $$\frac{- \frac{5}{2} - 9 \left(- \frac{1}{4} + \frac{\sqrt{5}}{4}\right)^{2} + \frac{3 \sqrt{5}}{2}}{- \sqrt{5} - 2 + 12 \left(- \frac{1}{4} + \frac{\sqrt{5}}{4}\right)^{2}}$$ |
| EJS_N9P2_N2N10_GC00017 | EJS_N9P2_N2N10 | 0.001729316978612537 | sqrt(23)*(-211 + 44*sqrt(23))/46 | $$\frac{\sqrt{23} \left(-211 + 44 \sqrt{23}\right)}{46}$$ |
| EJS_N6N4_P6N8_GC00017 | EJS_N6N4_P6N8 | 0.001747899230745497 | sqrt(22)*(122/3 - 26*sqrt(22)/3)/44 | $$\frac{\sqrt{22} \cdot \left(\frac{122}{3} - \frac{26 \sqrt{22}}{3}\right)}{44}$$ |
| EJS_N8P3_P3P8_GC00017 | EJS_N8P3_P3P8 | 0.001767618299327392 | -sqrt(19)*(292/3 - 67*sqrt(19)/3)/38 | $$- \frac{\sqrt{19} \cdot \left(\frac{292}{3} - \frac{67 \sqrt{19}}{3}\right)}{38}$$ |
| EJS_N1P1_P8P9_GC00017 | EJS_N1P1_P8P9 | 0.001772424695866793 | -sqrt(113)*(53/8 - 5*sqrt(113)/8)/113 | $$- \frac{\sqrt{113} \cdot \left(\frac{53}{8} - \frac{5 \sqrt{113}}{8}\right)}{113}$$ |
| EJS_P3N4_N9N8_GC00017 | EJS_P3N4_N9N8 | 0.001784281638280169 | sqrt(7)*(53/9 - 20*sqrt(7)/9)/14 | $$\frac{\sqrt{7} \cdot \left(\frac{53}{9} - \frac{20 \sqrt{7}}{9}\right)}{14}$$ |
| EJS_N10P7_N3N5_GC00017 | EJS_N10P7_N3N5 | 0.001789132090790507 | sqrt(13)*(-155/6 + 43*sqrt(13)/6)/13 | $$\frac{\sqrt{13} \left(- \frac{155}{6} + \frac{43 \sqrt{13}}{6}\right)}{13}$$ |
| EJS_P7N9_N10N9_GC00018 | EJS_P7N9_N10N9 | 0.001806080672884933 | sqrt(41)*(173/10 - 27*sqrt(41)/10)/41 | $$\frac{\sqrt{41} \cdot \left(\frac{173}{10} - \frac{27 \sqrt{41}}{10}\right)}{41}$$ |
| EJS_N10P9_P7P7_GC00018 | EJS_N10P9_P7P7 | 0.001808608105064389 | -sqrt(77)*(99/2 - 79*sqrt(77)/14)/77 | $$- \frac{\sqrt{77} \cdot \left(\frac{99}{2} - \frac{79 \sqrt{77}}{14}\right)}{77}$$ |
| EJS_N4P2_N4N9_GC00018 | EJS_N4P2_N4N9 | 0.001810340319610375 | sqrt(65)*(-137/4 + 17*sqrt(65)/4)/65 | $$\frac{\sqrt{65} \left(- \frac{137}{4} + \frac{17 \sqrt{65}}{4}\right)}{65}$$ |
| EJS_N4N1_P2N7_GC00018 | EJS_N4N1_P2N7 | 0.001814654931114840 | sqrt(57)*(219/4 - 29*sqrt(57)/4)/57 | $$\frac{\sqrt{57} \cdot \left(\frac{219}{4} - \frac{29 \sqrt{57}}{4}\right)}{57}$$ |
| EJS_N7P1_N1N8_GC00018 | EJS_N7P1_N1N8 | 0.001818241927340115 | sqrt(15)*(-213 + 55*sqrt(15))/30 | $$\frac{\sqrt{15} \left(-213 + 55 \sqrt{15}\right)}{30}$$ |
| EJS_N1P0_P1N8_GC00018 | EJS_N1P0_P1N8 | 0.001837813099494063 | sqrt(17)*(33 - 8*sqrt(17))/34 | $$\frac{\sqrt{17} \cdot \left(33 - 8 \sqrt{17}\right)}{34}$$ |
| EJS_P7N2_N3N10_GC00018 | EJS_P7N2_N3N10 | 0.001838086239954756 | sqrt(22)*(319/3 - 68*sqrt(22)/3)/44 | $$\frac{\sqrt{22} \cdot \left(\frac{319}{3} - \frac{68 \sqrt{22}}{3}\right)}{44}$$ |
| EJS_P1N1_N10N10_GC00018 | EJS_P1N1_N10N10 | 0.001848057057531969 | sqrt(15)*(7/2 - 9*sqrt(15)/10)/30 | $$\frac{\sqrt{15} \cdot \left(\frac{7}{2} - \frac{9 \sqrt{15}}{10}\right)}{30}$$ |
| EJS_N1P0_P2N10_GC00018 | EJS_N1P0_P2N10 | 0.001851166488378312 | sqrt(3)*(26 - 15*sqrt(3))/18 | $$\frac{\sqrt{3} \cdot \left(26 - 15 \sqrt{3}\right)}{18}$$ |
| EJS_P5N1_N2N9_GC00018 | EJS_P5N1_N2N9 | 0.001867836436273010 | sqrt(73)*(94 - 11*sqrt(73))/73 | $$\frac{\sqrt{73} \cdot \left(94 - 11 \sqrt{73}\right)}{73}$$ |
| EJS_N6P4_N6N10_GC00018 | EJS_N6P4_N6N10 | 0.001880077965244093 | sqrt(19)*(-122/3 + 28*sqrt(19)/3)/38 | $$\frac{\sqrt{19} \left(- \frac{122}{3} + \frac{28 \sqrt{19}}{3}\right)}{38}$$ |
| EJS_N2P1_N4N10_GC00018 | EJS_N2P1_N4N10 | 0.001880443683582853 | sqrt(21)*(-87/4 + 19*sqrt(21)/4)/42 | $$\frac{\sqrt{21} \left(- \frac{87}{4} + \frac{19 \sqrt{21}}{4}\right)}{42}$$ |
| EJS_N9P6_P5P7_GC00018 | EJS_N9P6_P5P7 | 0.001890618185424796 | -sqrt(69)*(573/10 - 69*sqrt(69)/10)/69 | $$- \frac{\sqrt{69} \cdot \left(\frac{573}{10} - \frac{69 \sqrt{69}}{10}\right)}{69}$$ |
| EJS_N3N2_P8N10_GC00018 | EJS_N3N2_P8N10 | 0.001893043490525139 | sqrt(33)*(23 - 4*sqrt(33))/66 | $$\frac{\sqrt{33} \cdot \left(23 - 4 \sqrt{33}\right)}{66}$$ |
| EJS_N2P3_P8P4_GC00018 | EJS_N2P3_P8P4 | 0.001896555337319404 | -sqrt(3)*(19/4 - 11*sqrt(3)/4)/12 | $$- \frac{\sqrt{3} \cdot \left(\frac{19}{4} - \frac{11 \sqrt{3}}{4}\right)}{12}$$ |
| EJS_N2P0_P1N10_GC00019 | EJS_N2P0_P1N10 | 0.001922892047385628 | sqrt(26)*(102 - 20*sqrt(26))/52 | $$\frac{\sqrt{26} \cdot \left(102 - 20 \sqrt{26}\right)}{52}$$ |
| EJS_N9N7_P7N8_GC00019 | EJS_N9N7_P7N8 | 0.001925923402238218 | sqrt(23)*(379/7 - 79*sqrt(23)/7)/46 | $$\frac{\sqrt{23} \cdot \left(\frac{379}{7} - \frac{79 \sqrt{23}}{7}\right)}{46}$$ |
| EJS_N9P4_P4P9_GC00019 | EJS_N9P4_P4P9 | 0.001940747289510757 | -sqrt(97)*(837/8 - 85*sqrt(97)/8)/97 | $$- \frac{\sqrt{97} \cdot \left(\frac{837}{8} - \frac{85 \sqrt{97}}{8}\right)}{97}$$ |
| EJS_N4P1_N2N10_GC00019 | EJS_N4P1_N2N10 | 0.001951142831754844 | sqrt(23)*(-187/2 + 39*sqrt(23)/2)/46 | $$\frac{\sqrt{23} \left(- \frac{187}{2} + \frac{39 \sqrt{23}}{2}\right)}{46}$$ |
| EJS_N10N2_P2N9_GC00019 | EJS_N10N2_P2N9 | 0.001953996138011539 | sqrt(89)*(217 - 23*sqrt(89))/89 | $$\frac{\sqrt{89} \cdot \left(217 - 23 \sqrt{89}\right)}{89}$$ |
| EJS_P6N3_N5N10_GC00019 | EJS_P6N3_N5N10 | 0.001973342624463725 | sqrt(5)*(51 - 114*sqrt(5)/5)/20 | $$\frac{\sqrt{5} \cdot \left(51 - \frac{114 \sqrt{5}}{5}\right)}{20}$$ |
| EJS_N8P1_N1N10_GC00019 | EJS_N8P1_N1N10 | 0.001977897621253166 | sqrt(6)*(-387 + 158*sqrt(6))/24 | $$\frac{\sqrt{6} \left(-387 + 158 \sqrt{6}\right)}{24}$$ |
| EJS_P5N1_N1N5_GC00019 | EJS_P5N1_N1N5 | 0.001983962979580969 | sqrt(21)*(55 - 12*sqrt(21))/21 | $$\frac{\sqrt{21} \cdot \left(55 - 12 \sqrt{21}\right)}{21}$$ |
| EJS_N10N7_P7N9_GC00019 | EJS_N10N7_P7N9 | 0.001985906635902576 | sqrt(109)*(1013/14 - 97*sqrt(109)/14)/109 | $$\frac{\sqrt{109} \cdot \left(\frac{1013}{14} - \frac{97 \sqrt{109}}{14}\right)}{109}$$ |
| EJS_P8P1_P1N10_GC00020 | EJS_P8P1_P1N10 | 0.002018093964997407 | sqrt(26)*(-413 + 81*sqrt(26))/52 | $$\frac{\sqrt{26} \left(-413 + 81 \sqrt{26}\right)}{52}$$ |
| EJS_N8P7_N7N9_GC00020 | EJS_N8P7_N7N9 | 0.002032375162149404 | sqrt(53)*(-473/14 + 65*sqrt(53)/14)/53 | $$\frac{\sqrt{53} \left(- \frac{473}{14} + \frac{65 \sqrt{53}}{14}\right)}{53}$$ |
| EJS_P4P1_P2N10_GC00020 | EJS_P4P1_P2N10 | 0.002032721884142679 | sqrt(3)*(-213/2 + 123*sqrt(3)/2)/18 | $$\frac{\sqrt{3} \left(- \frac{213}{2} + \frac{123 \sqrt{3}}{2}\right)}{18}$$ |
| EJS_N7P5_P6P8_GC00020 | EJS_N7P5_P6P8 | 0.002049593524617982 | -sqrt(22)*(143/3 - 61*sqrt(22)/6)/44 | $$- \frac{\sqrt{22} \cdot \left(\frac{143}{3} - \frac{61 \sqrt{22}}{6}\right)}{44}$$ |
| EJS_N4N2_P4N7_GC00020 | EJS_N4N2_P4N7 | 0.002050721323555799 | sqrt(65)*(121/4 - 15*sqrt(65)/4)/65 | $$\frac{\sqrt{65} \cdot \left(\frac{121}{4} - \frac{15 \sqrt{65}}{4}\right)}{65}$$ |
| EJS_P2P1_P4N10_GC00020 | EJS_P2P1_P4N10 | 0.002053348249142433 | sqrt(29)*(-113/4 + 21*sqrt(29)/4)/58 | $$\frac{\sqrt{29} \left(- \frac{113}{4} + \frac{21 \sqrt{29}}{4}\right)}{58}$$ |
| EJS_N7P1_P1P8_GC00020 | EJS_N7P1_P1P8 | 0.002064058230875611 | -sqrt(17)*(235 - 57*sqrt(17))/34 | $$- \frac{\sqrt{17} \cdot \left(235 - 57 \sqrt{17}\right)}{34}$$ |
| EJS_P6N4_N5N8_GC00020 | EJS_P6N4_N5N8 | 0.002065630835348890 | sqrt(11)*(146/5 - 44*sqrt(11)/5)/22 | $$\frac{\sqrt{11} \cdot \left(\frac{146}{5} - \frac{44 \sqrt{11}}{5}\right)}{22}$$ |
| EJS_P1P1_P8N10_GC00020 | EJS_P1P1_P8N10 | 0.002069229674439762 | sqrt(33)*(-63/8 + 11*sqrt(33)/8)/66 | $$\frac{\sqrt{33} \left(- \frac{63}{8} + \frac{11 \sqrt{33}}{8}\right)}{66}$$ |
| EJS_P7N2_N2N7_GC00020 | EJS_P7N2_N2N7 | 0.002075582117606430 | sqrt(41)*(301/4 - 47*sqrt(41)/4)/41 | $$\frac{\sqrt{41} \cdot \left(\frac{301}{4} - \frac{47 \sqrt{41}}{4}\right)}{41}$$ |
| EJS_N2P1_N3N7_GC00020 | EJS_N2P1_N3N7 | 0.002080000479462362 | sqrt(37)*(-79/6 + 13*sqrt(37)/6)/37 | $$\frac{\sqrt{37} \left(- \frac{79}{6} + \frac{13 \sqrt{37}}{6}\right)}{37}$$ |
| EJS_N7N6_P6N6_GC00020 | EJS_N7N6_P6N6 | 0.002082791080997448 | sqrt(15)*(31 - 8*sqrt(15))/30 | $$\frac{\sqrt{15} \cdot \left(31 - 8 \sqrt{15}\right)}{30}$$ |
| EJS_N9N4_P2N4_GC00020 | EJS_N9N4_P2N4 | 0.002083116364643900 | sqrt(6)*(49 - 20*sqrt(6))/12 | $$\frac{\sqrt{6} \cdot \left(49 - 20 \sqrt{6}\right)}{12}$$ |
| EJS_N8N4_P5N9_GC00020 | EJS_N8N4_P5N9 | 0.002084133204316996 | sqrt(101)*(382/5 - 38*sqrt(101)/5)/101 | $$\frac{\sqrt{101} \cdot \left(\frac{382}{5} - \frac{38 \sqrt{101}}{5}\right)}{101}$$ |
| EJS_N1N1_P8N6_GC00020 | EJS_N1N1_P8N6 | 0.002095820378353514 | sqrt(17)*(29/8 - 7*sqrt(17)/8)/34 | $$\frac{\sqrt{17} \cdot \left(\frac{29}{8} - \frac{7 \sqrt{17}}{8}\right)}{34}$$ |
| EJS_N2N1_P5N8_GC00020 | EJS_N2N1_P5N8 | 0.002099543840740573 | sqrt(21)*(78/5 - 17*sqrt(21)/5)/42 | $$\frac{\sqrt{21} \cdot \left(\frac{78}{5} - \frac{17 \sqrt{21}}{5}\right)}{42}$$ |
| EJS_P3N1_N2N6_GC00021 | EJS_P3N1_N2N6 | 0.002100321353806306 | sqrt(7)*(45/2 - 17*sqrt(7)/2)/14 | $$\frac{\sqrt{7} \cdot \left(\frac{45}{2} - \frac{17 \sqrt{7}}{2}\right)}{14}$$ |
| EJS_N4N5_P8N5_GC00021 | EJS_N4N5_P8N5 | 0.002103846783082996 | sqrt(57)*(189/16 - 25*sqrt(57)/16)/57 | $$\frac{\sqrt{57} \cdot \left(\frac{189}{16} - \frac{25 \sqrt{57}}{16}\right)}{57}$$ |
| EJS_N6N2_P3N8_GC00021 | EJS_N6N2_P3N8 | 0.002104997297077494 | sqrt(19)*(218/3 - 50*sqrt(19)/3)/38 | $$\frac{\sqrt{19} \cdot \left(\frac{218}{3} - \frac{50 \sqrt{19}}{3}\right)}{38}$$ |
| EJS_N5P4_P6P7_GC00021 | EJS_N5P4_P6P7 | 0.002108165307376850 | -sqrt(73)*(111/4 - 13*sqrt(73)/4)/73 | $$- \frac{\sqrt{73} \cdot \left(\frac{111}{4} - \frac{13 \sqrt{73}}{4}\right)}{73}$$ |
| EJS_N8N5_P7N10_GC00021 | EJS_N8N5_P7N10 | 0.002113602691595700 | sqrt(2)*(481/7 - 340*sqrt(2)/7)/16 | $$\frac{\sqrt{2} \cdot \left(\frac{481}{7} - \frac{340 \sqrt{2}}{7}\right)}{16}$$ |
| EJS_N3P4_N10N9_GC00021 | EJS_N3P4_N10N9 | 0.002122850118745418 | sqrt(41)*(-147/20 + 23*sqrt(41)/20)/41 | $$\frac{\sqrt{41} \left(- \frac{147}{20} + \frac{23 \sqrt{41}}{20}\right)}{41}$$ |
| EJS_P0N1N1_N1P3N3_GC00021 | EJS_P0N1N1_N1P3N3 | 0.002165963626761758 | (-2**(1/3) + 4*(1 - 2**(1/3))**2 + 1)/(-3 + 3*(1 - 2**(1/3))**2 + 6*2**(1/3)) | $$\frac{- \sqrt[3]{2} + 4 \left(1 - \sqrt[3]{2}\right)^{2} + 1}{-3 + 3 \left(1 - \sqrt[3]{2}\right)^{2} + 6 \cdot \sqrt[3]{2}}$$ |
| EJS_N4N3_P7N8_GC00021 | EJS_N4N3_P7N8 | 0.002172968684897152 | sqrt(23)*(24 - 5*sqrt(23))/46 | $$\frac{\sqrt{23} \cdot \left(24 - 5 \sqrt{23}\right)}{46}$$ |
| EJS_N8N7_P8N8_GC00022 | EJS_N8N7_P8N8 | 0.002200158794510302 | sqrt(6)*(87/2 - 71*sqrt(6)/4)/24 | $$\frac{\sqrt{6} \cdot \left(\frac{87}{2} - \frac{71 \sqrt{6}}{4}\right)}{24}$$ |
| EJS_N6P3_P4P8_GC00022 | EJS_N6P3_P4P8 | 0.002206264125599365 | -sqrt(5)*(57 - 51*sqrt(5)/2)/20 | $$- \frac{\sqrt{5} \cdot \left(57 - \frac{51 \sqrt{5}}{2}\right)}{20}$$ |
| EJS_P9P2_P2N10_GC00022 | EJS_P9P2_P2N10 | 0.002214277279907047 | sqrt(3)*(-239 + 138*sqrt(3))/18 | $$\frac{\sqrt{3} \left(-239 + 138 \sqrt{3}\right)}{18}$$ |
| EJS_N10P6_P5P8_GC00022 | EJS_N10P6_P5P8 | 0.002215124701900178 | -sqrt(21)*(394/5 - 86*sqrt(21)/5)/42 | $$- \frac{\sqrt{21} \cdot \left(\frac{394}{5} - \frac{86 \sqrt{21}}{5}\right)}{42}$$ |
| EJS_N10N8_N5P7_GC00022 | EJS_N10N8_N5P7 | 0.002224295113532229 | -sqrt(29)*(-167/5 + 31*sqrt(29)/5)/29 | $$- \frac{\sqrt{29} \left(- \frac{167}{5} + \frac{31 \sqrt{29}}{5}\right)}{29}$$ |
| EJS_P5P4_P8N10_GC00022 | EJS_P5P4_P8N10 | 0.002245415858354385 | sqrt(33)*(-155/4 + 27*sqrt(33)/4)/66 | $$\frac{\sqrt{33} \left(- \frac{155}{4} + \frac{27 \sqrt{33}}{4}\right)}{66}$$ |
| EJS_N4N2_P6N10_GC00023 | EJS_N4N2_P6N10 | 0.002303389522110563 | sqrt(31)*(39 - 7*sqrt(31))/62 | $$\frac{\sqrt{31} \cdot \left(39 - 7 \sqrt{31}\right)}{62}$$ |
| EJS_P6P2_P3N10_GC00023 | EJS_P6P2_P3N10 | 0.002304404414455789 | sqrt(7)*(-328/3 + 124*sqrt(7)/3)/28 | $$\frac{\sqrt{7} \left(- \frac{328}{3} + \frac{124 \sqrt{7}}{3}\right)}{28}$$ |
| EJS_N8N1_P1N7_GC00023 | EJS_N8N1_P1N7 | 0.002317019352972476 | sqrt(53)*(415/2 - 57*sqrt(53)/2)/53 | $$\frac{\sqrt{53} \cdot \left(\frac{415}{2} - \frac{57 \sqrt{53}}{2}\right)}{53}$$ |
| EJS_N2P2_P8P8_GC00023 | EJS_N2P2_P8P8 | 0.002317201224376704 | -sqrt(6)*(11 - 9*sqrt(6)/2)/24 | $$- \frac{\sqrt{6} \cdot \left(11 - \frac{9 \sqrt{6}}{2}\right)}{24}$$ |
| EJS_N10N3_P1N3_GC00023 | EJS_N10N3_P1N3 | 0.002330837700566380 | sqrt(13)*(119/2 - 33*sqrt(13)/2)/13 | $$\frac{\sqrt{13} \cdot \left(\frac{119}{2} - \frac{33 \sqrt{13}}{2}\right)}{13}$$ |
| EJS_N9P7_N7N10_GC00023 | EJS_N9P7_N7N10 | 0.002343167198458843 | sqrt(2)*(-352/7 + 249*sqrt(2)/7)/12 | $$\frac{\sqrt{2} \left(- \frac{352}{7} + \frac{249 \sqrt{2}}{7}\right)}{12}$$ |
| EJS_P9N1_N1N8_GC00023 | EJS_P9N1_N1N8 | 0.002347340234654780 | sqrt(15)*(275 - 71*sqrt(15))/30 | $$\frac{\sqrt{15} \cdot \left(275 - 71 \sqrt{15}\right)}{30}$$ |
| EJS_N8P2_N2N9_GC00023 | EJS_N8P2_N2N9 | 0.002348494178480690 | sqrt(73)*(-299/2 + 35*sqrt(73)/2)/73 | $$\frac{\sqrt{73} \left(- \frac{299}{2} + \frac{35 \sqrt{73}}{2}\right)}{73}$$ |
| EJS_N9P3_N3N10_GC00023 | EJS_N9P3_N3N10 | 0.002351287818490467 | sqrt(22)*(-136 + 29*sqrt(22))/44 | $$\frac{\sqrt{22} \left(-136 + 29 \sqrt{22}\right)}{44}$$ |
| EJS_N8P6_P7P9_GC00023 | EJS_N8P6_P7P9 | 0.002352884499876902 | -sqrt(109)*(407/7 - 39*sqrt(109)/7)/109 | $$- \frac{\sqrt{109} \cdot \left(\frac{407}{7} - \frac{39 \sqrt{109}}{7}\right)}{109}$$ |
| EJS_N7P8_P8P6_GC00023 | EJS_N7P8_P8P6 | 0.002353827657212965 | -sqrt(17)*(103/4 - 25*sqrt(17)/4)/34 | $$- \frac{\sqrt{17} \cdot \left(\frac{103}{4} - \frac{25 \sqrt{17}}{4}\right)}{34}$$ |
| EJS_N5N3_P7N10_GC00023 | EJS_N5N3_P7N10 | 0.002357756356504595 | sqrt(2)*(300/7 - 212*sqrt(2)/7)/16 | $$\frac{\sqrt{2} \cdot \left(\frac{300}{7} - \frac{212 \sqrt{2}}{7}\right)}{16}$$ |
| EJS_N1P1_N7N9_GC00023 | EJS_N1P1_N7N9 | 0.002363377926859757 | sqrt(53)*(-29/7 + 4*sqrt(53)/7)/53 | $$\frac{\sqrt{53} \left(- \frac{29}{7} + \frac{4 \sqrt{53}}{7}\right)}{53}$$ |
| EJS_N6P7_N9N9_GC00023 | EJS_N6P7_N9N9 | 0.002365137361356465 | sqrt(5)*(-35/2 + 47*sqrt(5)/6)/15 | $$\frac{\sqrt{5} \left(- \frac{35}{2} + \frac{47 \sqrt{5}}{6}\right)}{15}$$ |
| EJS_P4N3_N4N6_GC00023 | EJS_P4N3_N4N6 | 0.002379873562252893 | sqrt(5)*(47/4 - 21*sqrt(5)/4)/10 | $$\frac{\sqrt{5} \cdot \left(\frac{47}{4} - \frac{21 \sqrt{5}}{4}\right)}{10}$$ |
| EJS_N10N6_P6N9_GC00023 | EJS_N10N6_P6N9 | 0.002380598177972070 | sqrt(105)*(82 - 8*sqrt(105))/105 | $$\frac{\sqrt{105} \cdot \left(82 - 8 \sqrt{105}\right)}{105}$$ |
| EJS_N1P1_P6P6_GC00023 | EJS_N1P1_P6P6 | 0.002385831402220800 | -sqrt(15)*(9/2 - 7*sqrt(15)/6)/30 | $$- \frac{\sqrt{15} \cdot \left(\frac{9}{2} - \frac{7 \sqrt{15}}{6}\right)}{30}$$ |
| EJS_N6P2_P2P6_GC00023 | EJS_N6P2_P2P6 | 0.002392645800445886 | -sqrt(11)*(63 - 19*sqrt(11))/22 | $$- \frac{\sqrt{11} \cdot \left(63 - 19 \sqrt{11}\right)}{22}$$ |
| EJS_P6N1_N2N10_GC00023 | EJS_P6N1_N2N10 | 0.002394794538039459 | sqrt(23)*(283/2 - 59*sqrt(23)/2)/46 | $$\frac{\sqrt{23} \cdot \left(\frac{283}{2} - \frac{59 \sqrt{23}}{2}\right)}{46}$$ |
| EJS_N1P1_P7P8_GC00024 | EJS_N1P1_P7P8 | 0.002420013967556086 | -sqrt(23)*(43/7 - 9*sqrt(23)/7)/46 | $$- \frac{\sqrt{23} \cdot \left(\frac{43}{7} - \frac{9 \sqrt{23}}{7}\right)}{46}$$ |
| EJS_P9P7_P8N10_GC00024 | EJS_P9P7_P8N10 | 0.002421602042269008 | sqrt(33)*(-557/8 + 97*sqrt(33)/8)/66 | $$\frac{\sqrt{33} \left(- \frac{557}{8} + \frac{97 \sqrt{33}}{8}\right)}{66}$$ |
| EJS_N10N3_P3N9_GC00024 | EJS_N10N3_P3N9 | 0.002427836219857762 | sqrt(93)*(299/2 - 31*sqrt(93)/2)/93 | $$\frac{\sqrt{93} \cdot \left(\frac{299}{2} - \frac{31 \sqrt{93}}{2}\right)}{93}$$ |
| EJS_N7P5_P4P5_GC00024 | EJS_N7P5_P4P5 | 0.002439619564605903 | -sqrt(41)*(32 - 5*sqrt(41))/41 | $$- \frac{\sqrt{41} \cdot \left(32 - 5 \sqrt{41}\right)}{41}$$ |
| EJS_N10N8_P9N10_GC00024 | EJS_N10N8_P9N10 | 0.002450479987809308 | sqrt(34)*(70 - 12*sqrt(34))/68 | $$\frac{\sqrt{34} \cdot \left(70 - 12 \sqrt{34}\right)}{68}$$ |
| EJS_N2N1_P3N5_GC00024 | EJS_N2N1_P3N5 | 0.002455358243156392 | sqrt(37)*(67/6 - 11*sqrt(37)/6)/37 | $$\frac{\sqrt{37} \cdot \left(\frac{67}{6} - \frac{11 \sqrt{37}}{6}\right)}{37}$$ |
| EJS_N2P2N1_P1P3P3_GC00024 | EJS_N2P2N1_P1P3P3 | 0.002479828473064989 | (-8*2**(1/3) + (-1 + 2**(1/3))**2 + 10)/(-6*2**(1/3) - 3*(-1 + 2**(1/3))**2 + 3) | $$\frac{- 8 \cdot \sqrt[3]{2} + \left(-1 + \sqrt[3]{2}\right)^{2} + 10}{- 6 \cdot \sqrt[3]{2} - 3 \left(-1 + \sqrt[3]{2}\right)^{2} + 3}$$ |
| EJS_N8N7_P9N9_GC00024 | EJS_N8N7_P9N9 | 0.002487664560841660 | sqrt(13)*(95/2 - 79*sqrt(13)/6)/39 | $$\frac{\sqrt{13} \cdot \left(\frac{95}{2} - \frac{79 \sqrt{13}}{6}\right)}{39}$$ |
| EJS_N4N3_P8N9_GC00024 | EJS_N4N3_P8N9 | 0.002494752369955478 | sqrt(113)*(415/16 - 39*sqrt(113)/16)/113 | $$\frac{\sqrt{113} \cdot \left(\frac{415}{16} - \frac{39 \sqrt{113}}{16}\right)}{113}$$ |
| EJS_N1P0_P2N9_GC00024 | EJS_N1P0_P2N9 | 0.002495495013514954 | sqrt(89)*(85/4 - 9*sqrt(89)/4)/89 | $$\frac{\sqrt{89} \cdot \left(\frac{85}{4} - \frac{9 \sqrt{89}}{4}\right)}{89}$$ |
| EJS_P7N4_N5N9_GC00025 | EJS_P7N4_N5N9 | 0.002500164906504386 | sqrt(61)*(461/10 - 59*sqrt(61)/10)/61 | $$\frac{\sqrt{61} \cdot \left(\frac{461}{10} - \frac{59 \sqrt{61}}{10}\right)}{61}$$ |
| EJS_N2N1_P6N9_GC00025 | EJS_N2N1_P6N9 | 0.002504285208033083 | sqrt(105)*(65/4 - 19*sqrt(105)/12)/105 | $$\frac{\sqrt{105} \cdot \left(\frac{65}{4} - \frac{19 \sqrt{105}}{12}\right)}{105}$$ |
| EJS_N5P4_P3P3_GC00025 | EJS_N5P4_P3P3 | 0.002507258244777138 | -sqrt(21)*(29/2 - 19*sqrt(21)/6)/21 | $$- \frac{\sqrt{21} \cdot \left(\frac{29}{2} - \frac{19 \sqrt{21}}{6}\right)}{21}$$ |
| EJS_P5N3_N6N10_GC00025 | EJS_P5N3_N6N10 | 0.002518786955430167 | sqrt(19)*(205/6 - 47*sqrt(19)/6)/38 | $$\frac{\sqrt{19} \cdot \left(\frac{205}{6} - \frac{47 \sqrt{19}}{6}\right)}{38}$$ |
| EJS_P3P2_P6N10_GC00025 | EJS_P3P2_P6N10 | 0.002521353269505639 | sqrt(31)*(-89/3 + 16*sqrt(31)/3)/62 | $$\frac{\sqrt{31} \left(- \frac{89}{3} + \frac{16 \sqrt{31}}{3}\right)}{62}$$ |
| EJS_N3P2_P3P4_GC00025 | EJS_N3P2_P3P4 | 0.002552416443098765 | -sqrt(7)*(37/3 - 14*sqrt(7)/3)/14 | $$- \frac{\sqrt{7} \cdot \left(\frac{37}{3} - \frac{14 \sqrt{7}}{3}\right)}{14}$$ |
| EJS_N4N3_P9N10_GC00025 | EJS_N4N3_P9N10 | 0.002563603931651010 | sqrt(34)*(251/9 - 43*sqrt(34)/9)/68 | $$\frac{\sqrt{34} \cdot \left(\frac{251}{9} - \frac{43 \sqrt{34}}{9}\right)}{68}$$ |
| EJS_N3P3_P9P9_GC00025 | EJS_N3P3_P9P9 | 0.002566077990979300 | -sqrt(13)*(18 - 5*sqrt(13))/39 | $$- \frac{\sqrt{13} \cdot \left(18 - 5 \sqrt{13}\right)}{39}$$ |
| EJS_N9N4_P5N10_GC00025 | EJS_N9N4_P5N10 | 0.002570570505351614 | sqrt(30)*(103 - 94*sqrt(30)/5)/60 | $$\frac{\sqrt{30} \cdot \left(103 - \frac{94 \sqrt{30}}{5}\right)}{60}$$ |
| EJS_N2N1_P7N10_GC00026 | EJS_N2N1_P7N10 | 0.002601910021413489 | sqrt(2)*(17 - 12*sqrt(2))/16 | $$\frac{\sqrt{2} \cdot \left(17 - 12 \sqrt{2}\right)}{16}$$ |
| EJS_N10N5_P5N9_GC00026 | EJS_N10N5_P5N9 | 0.002605166505396245 | sqrt(101)*(191/2 - 19*sqrt(101)/2)/101 | $$\frac{\sqrt{101} \cdot \left(\frac{191}{2} - \frac{19 \sqrt{101}}{2}\right)}{101}$$ |
| EJS_N2P0_P1N9_GC00026 | EJS_N2P0_P1N9 | 0.002613999474231138 | sqrt(85)*(83 - 9*sqrt(85))/85 | $$\frac{\sqrt{85} \cdot \left(83 - 9 \sqrt{85}\right)}{85}$$ |
| EJS_N9N6_P6N8_GC00026 | EJS_N9N6_P6N8 | 0.002621848846118246 | sqrt(22)*(61 - 13*sqrt(22))/44 | $$\frac{\sqrt{22} \cdot \left(61 - 13 \sqrt{22}\right)}{44}$$ |
| EJS_N9N2_P2N8_GC00026 | EJS_N9N2_P2N8 | 0.002627441047993555 | sqrt(2)*(157 - 111*sqrt(2))/12 | $$\frac{\sqrt{2} \cdot \left(157 - 111 \sqrt{2}\right)}{12}$$ |
| EJS_N6P4_P6P9_GC00026 | EJS_N6P4_P6P9 | 0.002627972238094095 | -sqrt(105)*(99/2 - 29*sqrt(105)/6)/105 | $$- \frac{\sqrt{105} \cdot \left(\frac{99}{2} - \frac{29 \sqrt{105}}{6}\right)}{105}$$ |
| EJS_P8N4_N5N10_GC00026 | EJS_P8N4_N5N10 | 0.002631123499284967 | sqrt(5)*(68 - 152*sqrt(5)/5)/20 | $$\frac{\sqrt{5} \cdot \left(68 - \frac{152 \sqrt{5}}{5}\right)}{20}$$ |
| EJS_N10N4_P4N9_GC00026 | EJS_N10N4_P4N9 | 0.002631861421640428 | sqrt(97)*(463/4 - 47*sqrt(97)/4)/97 | $$\frac{\sqrt{97} \cdot \left(\frac{463}{4} - \frac{47 \sqrt{97}}{4}\right)}{97}$$ |
| EJS_N8N6_P6N7_GC00026 | EJS_N8N6_P6N7 | 0.002650667829099907 | sqrt(73)*(265/6 - 31*sqrt(73)/6)/73 | $$\frac{\sqrt{73} \cdot \left(\frac{265}{6} - \frac{31 \sqrt{73}}{6}\right)}{73}$$ |
| EJS_N10P2_P1P5_GC00026 | EJS_N10P2_P1P5 | 0.002652655212739159 | -sqrt(29)*(140 - 26*sqrt(29))/29 | $$- \frac{\sqrt{29} \cdot \left(140 - 26 \sqrt{29}\right)}{29}$$ |
| EJS_N6P5_P7P8_GC00026 | EJS_N6P5_P7P8 | 0.002667059250215019 | -sqrt(23)*(254/7 - 53*sqrt(23)/7)/46 | $$- \frac{\sqrt{23} \cdot \left(\frac{254}{7} - \frac{53 \sqrt{23}}{7}\right)}{46}$$ |
| EJS_N1P0_P3N10_GC00026 | EJS_N1P0_P3N10 | 0.002676422457420253 | sqrt(7)*(53/3 - 20*sqrt(7)/3)/28 | $$\frac{\sqrt{7} \cdot \left(\frac{53}{3} - \frac{20 \sqrt{7}}{3}\right)}{28}$$ |
| EJS_P2P2_P9N10_GC00026 | EJS_P2P2_P9N10 | 0.002676727875492711 | sqrt(34)*(-128/9 + 22*sqrt(34)/9)/68 | $$\frac{\sqrt{34} \left(- \frac{128}{9} + \frac{22 \sqrt{34}}{9}\right)}{68}$$ |
| EJS_N9P8_P6P6_GC00026 | EJS_N9P8_P6P6 | 0.002688871723444153 | -sqrt(15)*(40 - 31*sqrt(15)/3)/30 | $$- \frac{\sqrt{15} \cdot \left(40 - \frac{31 \sqrt{15}}{3}\right)}{30}$$ |
| EJS_N8N9_P7N5_GC00026 | EJS_N8N9_P7N5 | 0.002694380691570111 | sqrt(53)*(51/2 - 7*sqrt(53)/2)/53 | $$\frac{\sqrt{53} \cdot \left(\frac{51}{2} - \frac{7 \sqrt{53}}{2}\right)}{53}$$ |
| EJS_N6P1_N1N7_GC00027 | EJS_N6P1_N1N7 | 0.002710206251927782 | sqrt(5)*(-275/2 + 123*sqrt(5)/2)/15 | $$\frac{\sqrt{5} \left(- \frac{275}{2} + \frac{123 \sqrt{5}}{2}\right)}{15}$$ |
| EJS_N6P3_N4N9_GC00027 | EJS_N6P3_N4N9 | 0.002715510479415563 | sqrt(65)*(-411/8 + 51*sqrt(65)/8)/65 | $$\frac{\sqrt{65} \left(- \frac{411}{8} + \frac{51 \sqrt{65}}{8}\right)}{65}$$ |
| EJS_P7P3_P4N10_GC00027 | EJS_P7P3_P4N10 | 0.002716512052327222 | sqrt(29)*(-393/4 + 73*sqrt(29)/4)/58 | $$\frac{\sqrt{29} \left(- \frac{393}{4} + \frac{73 \sqrt{29}}{4}\right)}{58}$$ |
| EJS_N5P4_N7N10_GC00027 | EJS_N5P4_N7N10 | 0.002718515919600779 | sqrt(2)*(-195/7 + 138*sqrt(2)/7)/12 | $$\frac{\sqrt{2} \left(- \frac{195}{7} + \frac{138 \sqrt{2}}{7}\right)}{12}$$ |
| EJS_N7P1_N1N9_GC00027 | EJS_N7P1_N1N9 | 0.002723202978477916 | sqrt(77)*(-272 + 31*sqrt(77))/77 | $$\frac{\sqrt{77} \left(-272 + 31 \sqrt{77}\right)}{77}$$ |
| EJS_N7P1_P1P9_GC00027 | EJS_N7P1_P1P9 | 0.002757471748214629 | -sqrt(85)*(295 - 32*sqrt(85))/85 | $$- \frac{\sqrt{85} \cdot \left(295 - 32 \sqrt{85}\right)}{85}$$ |
| EJS_N1P1_P7P9_GC00027 | EJS_N1P1_P7P9 | 0.002757616692858965 | -sqrt(109)*(52/7 - 5*sqrt(109)/7)/109 | $$- \frac{\sqrt{109} \cdot \left(\frac{52}{7} - \frac{5 \sqrt{109}}{7}\right)}{109}$$ |
| EJS_N9P4_N4N10_GC00027 | EJS_N9P4_N4N10 | 0.002768905877375222 | sqrt(21)*(-197/2 + 43*sqrt(21)/2)/42 | $$\frac{\sqrt{21} \left(- \frac{197}{2} + \frac{43 \sqrt{21}}{2}\right)}{42}$$ |


# Affichage des lignes 0 - 199 (total de 200 sur 300 000) 

**SELECT CTEname, left(constanteFloat, 20), constanteSymbols, constanteLatex, Fibovar 
FROM `geometricconstants` 
WHERE length(constanteSymbols) < 90 order by constantefloat asc limit 200;**

